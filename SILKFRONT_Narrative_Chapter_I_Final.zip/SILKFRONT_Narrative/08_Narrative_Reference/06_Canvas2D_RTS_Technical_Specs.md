# ТЕХНИЧЕСКАЯ СПЕЦИФИКАЦИЯ МЕХАНИК ДЛЯ ДВИЖКА CANVAS 2D RTS

> **Статус документа:** Техническое проектное предложение для разработчиков ядра SILKFRONT  
> **Раздел:** 08_Narrative_Reference  
> **Назначение:** Описание интеграции новых сюжетных механик 8 миссий в существующую архитектуру игры на Canvas 2D без нарушения стабильности симуляции и режима схватки  

---

## 1. Архитектурный контекст существующего проекта

Игра SILKFRONT разработана на базе чистого детерминированного бессерверного движка **HTML5 Canvas 2D** без использования сторонних фреймворков:

- **Ядро симуляции (`GAME/src/world.js`):** Независимо от DOM/Canvas. Фиксированный такт `DT = 1/20 с` (20 тиков в секунду). Полный детерминизм, единая точка входа приказов (`World.cmdMove/cmdAttack/cmdSmart/cmdGather/cmdReturn/cmdBuild/cmdTrain`).
- **Сетка и поиск путей (`GAME/src/path.js`):** Сетка `blocked: Uint8Array(MAP_W * MAP_H)` на 32-пиксельных тайлах. Поиск A* (8 направлений, запрет срезки углов, сглаживание по лучу видимости `los`).
- **Сущности и логика поведения (`GAME/src/units.js`):** Конечный автомат состояний `idle / move / amove / attack / gather / build / heal`.
- **Таблицы баланса и константы (`GAME/src/data.js`):** Словари `UNITS`, `BUILDINGS`, `RES`, `FACTIONS`.
- **Сценарный слой (`GAME/src/missions/index.js`, `ash-outskirts.js`):** `MissionScenario`, вехи целей (`reach`, `gather`, `building`, `train`, `destroy`), проверка раз в 0.5 с.
- **Отрисовка (`GAME/src/render.js`):** 2D Canvas-контекст, работающий с предзагруженными спрайт-атласами 10 юнитов через `Renderer`.
- **Связка и интерфейс (`GAME/src/game.js`, `input.js`, `hud.js`, `mission-hud.js`, `orders.js`, `sound.js`):** Накопление времени в `Game.frame()`, управление камерой, выделение рамкой, модальный брифинг, миникарта и синтезированный Web Audio звук.

> **Главный архитектурный принцип внедрения:**  
> Все новые сценарные механики должны реализовываться как **расширение сценарного слоя (`src/missions/index.js`)** и неинвазивные хуки в `World`, чтобы не сломать режим обычной схватки «Перевал» и уже готовую миссию «Пепельная окраина».

---

## 2. Анализ и спецификация новых механик

Ниже приведен детальный аудит каждой предлагаемой сюжетной механики относительно реального кода игры.

---

### 2.1. Механика поиска и присоединения нейтральных отрядов (Rescue / Recruit System)
- **Используется в:** Миссиях H3 («Разбитое знамя»), N3 («Эхо потерянных»).
- **Что уже есть в движке:**
  - `w.addUnit(type, owner, x, y)` умеет спавнить любых юнитов в произвольных координатах (`world.js:24`).
  - Система принадлежности игроку (`owner = 0` — игрок, `owner = 1` — враг).
  - В `World.prototype.walkable` и `canPlace` проверяется проходимость тайлов.
- **Чего нет:**
  - Понятия нейтрального спящего отряда (`owner = 2` или `isDormant = true`).
  - Проверки дистанции сближения героя с нейтральным юнитом для смены владельца.
- **Какие модули расширяются:**
  - `GAME/src/missions/index.js`: Добавление нового типа задачи в `MissionScenario`:
    ```javascript
    // o.kind === 'rescue'
    if (o.kind === 'rescue') {
      const hero = w.unitsOf(0).find(u => u.type === 'human_knight' || u.type === 'human_swordsman'); // лидер отряда
      const targetGroup = this.dormantUnits[o.squadId];
      if (hero && targetGroup && targetGroup.some(u => Math.hypot(u.x - hero.x, u.y - hero.y) <= o.radius * TILE)) {
        for (const u of targetGroup) {
          u.owner = 0; // переход под управление игрока
          u.isDormant = false;
        }
        done = true;
      }
    }
    ```
  - `GAME/src/units.js`: Добавить в начало `updateUnit` проверку: если `u.isDormant`, юнит пропускает логику поиска врагов и движения, находясь в состоянии `idle`.
- **Новые компоненты:** Объект группы `dormantUnits` в сценарии миссии.
- **Риски для схватки:** Нулевые. В схватке флаг `isDormant` не используется, нейтральные юниты отсутствуют.
- **Реализуемость без перестройки ядра:** Полная (менее 20 строк кода в сценарии).

---

### 2.2. Механика нулевой экономики и жесткого лимита армии (Zero-Economy / Hard Cap)
- **Используется в:** Миссиях H3 («Разбитое знамя»), N3 («Эхо потерянных»).
- **Что уже есть в движке:**
  - В `src/missions/ash-outskirts.js` уже можно задавать стартовые ресурсы `{ e: 0, w: 0 }`.
  - В `World.prototype.cmdTrain` и `cmdBuild` уже проверяются ресурсы и лимит населения (`world.js`).
- **Чего нет:**
  - Отключения кнопок постройки и найма в интерфейсе при отсутствии базы.
  - Счетчик живой силы на экране вместо счетчика рабочих.
- **Какие модули расширяются:**
  - `GAME/src/missions/index.js`: Флаг в описании миссии `noBase: true`.
  - `GAME/src/hud.js`: Если `w.meta.noBase === true`, панель строительства (`#build-bar`) скрывается, а клики по горячим клавишам постройки игнорируются.
  - `GAME/src/mission-hud.js`: Отображение в поле статуса: `«Бойцы: ${w.unitsOf(0).length} в строю»`.
- **Новые компоненты:** Нет.
- **Риски для схватки:** Нулевые. Схватка использует стандартный HUD.
- **Реализуемость без перестройки ядра:** Полная (правка условий видимости DOM-элементов).

---

### 2.3. Механика эскорта и санитарных обозов (Escort / Convoy Entity)
- **Используется в:** Миссиях H4 («Последний приказ»), N4 («Последнее Плетение»).
- **Что уже есть в движке:**
  - Объекты `unit` имеют `hp`, `maxHp`, `r` (радиус коллизии), координаты `x, y`, `speed`, `moving`.
  - Юниты умеют следовать по маршруту через `w.setOrder(u, { t: 'move', target: point })`.
- **Чего нет:**
  - Отдельного небоевого юнита «сани / колыбель» (без атаки, уязвимого).
  - Поведения «остановиться, если рядом нет союзной охраны».
- **Какие модули расширяются:**
  - `GAME/src/data.js`: Добавить в `UNITS` декларацию небоевой повозки:
    ```javascript
    cart_wagon: U({ fac: 'HUMANS', ru: 'Обоз с ранеными', role: 'Эвакуационный обоз (не атакует)',
      art: null, hp: 800, armor: 2, dmg: 0, speed: 55, cost: { e: 0, w: 0 }, supply: 0, time: 0, r: 16, h: 32, worker: false })
    ```
  - `GAME/src/missions/index.js`: В цикле `MissionScenario.prototype.update` добавить логику сопровождения:
    ```javascript
    for (const cart of this.convoyCarts) {
      const nearAllies = w.unitsOf(0).some(u => u !== cart && Math.hypot(u.x - cart.x, u.y - cart.y) <= 180);
      if (nearAllies && cart.order.t === 'idle') {
        const nextWp = this.getNextWaypoint(cart);
        if (nextWp) w.cmdMove(0, [cart.id], nextWp.x, nextWp.y);
      } else if (!nearAllies && cart.order.t === 'move') {
        w.cmdStop(0, [cart.id]); // Остановка при отсутствии охраны
      }
    }
    ```
- **Новые компоненты:** Массив путевых точек `waypoints` в сценарии.
- **Риски для схватки:** Отсутствуют: тип юнита `cart_wagon` не производится в Казармах.
- **Реализуемость без перестройки ядра:** Полная.

---

### 2.4. Механика эвакуационной зоны (Evacuation Zone Trigger)
- **Используется в:** Миссиях H4 («Последний приказ»), N4 («Последнее Плетение»).
- **Что уже есть в движке:**
  - В `ash-outskirts.js` уже есть задача `reach` (проверка вхождения юнита в радиус от точки: `Math.hypot(u.x - p.x, u.y - p.y) <= o.radius * TILE`).
- **Чего нет:**
  - Удаления спасенного юнита с карты (`w.remove(u)`) с фиксацией в счетчике эвакуации.
- **Какие модули расширяются:**
  - `GAME/src/missions/index.js`: Задача `o.kind === 'evacuate'`:
    ```javascript
    if (o.kind === 'evacuate') {
      for (const cart of [...this.convoyCarts]) {
        if (Math.hypot(cart.x - p.x, cart.y - p.y) <= o.radius * TILE) {
          w.remove(cart); // Удаление с карты после спасения
          this.convoyCarts.delete(cart);
          this.evacuatedCount++;
          w.emit(0, 'evac-success', `Обоз спасён! (${this.evacuatedCount}/${o.targetCount})`);
        }
      }
      done = this.evacuatedCount >= o.targetCount;
    }
    ```
- **Риски для схватки:** Нулевые.

---

### 2.5. Механика динамического изменения проходимости (Dynamic Blocking / Hazard)
- **Используется в:** Подрыв моста (H4), расчистка завалов (N3), камнепады (N4).
- **Что уже есть в движке:**
  - В `GAME/src/world.js` уже есть методы `w.occupy(e, true/false)`, меняющие массив `this.blocked` на лету при постройке зданий и вырубке деревьев (`depleteRes`).
  - Поиск пути в `path.js` читает массив `this.blocked` напрямую перед каждым вызовом `find()`.
- **Чего нет:**
  - Прямого метода изменения проходимости тайла без привязки к зданию или дереву.
- **Какие модули расширяются:**
  - `GAME/src/world.js`: Добавить 2 вспомогательных метода (по 4 строки):
    ```javascript
    setTileBlocked(tx, ty, on) {
      if (!this.inMap(tx, ty)) return;
      this.blocked[ty * this.w + tx] = on ? 1 : 0;
    }
    setAreaBlocked(x0, y0, x1, y1, on) {
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.setTileBlocked(x, y, on);
    }
    ```
  - Для разрушения моста в H4 сценарий просто вызывает: `w.setAreaBlocked(bridgeX0, bridgeY0, bridgeX1, bridgeY1, true)`. Сетка A* мгновенно перестраивает маршруты!
- **Риски для схватки:** Нулевые. Методы пассивны и вызываются только скриптами конкретных миссий.

---

### 2.6. Механика межмиссионных сохранений и переноса состояний (CampaignState)
- **Используется во всех миссиях 1–4 обеих кампаний.**
- **Что уже есть в движке:**
  - Запуск миссии через URL: `?mission=ash-outskirts` (`game.js:53`).
  - Завершение матча и статистика в `w.players[0].stats`.
- **Чего нет:**
  - Сохранения прогресса кампании в браузере между перезагрузками страницы.
- **Какие модули расширяются:**
  - `GAME/src/game.js`: Добавить работу с `localStorage`:
    ```javascript
    saveCampaignProgress(missionId, stateData) {
      try {
        const raw = localStorage.getItem('silkfront_campaign') || '{}';
        const data = JSON.parse(raw);
        data[missionId] = stateData;
        localStorage.setItem('silkfront_campaign', JSON.stringify(data));
      } catch (e) { /* ignore privacy mode */ }
    }
    getCampaignProgress() {
      try { return JSON.parse(localStorage.getItem('silkfront_campaign') || '{}'); }
      catch (e) { return {}; }
    }
    ```
  - В `createMission(id)` передавать сохранённое состояние: `const progress = game.getCampaignProgress();`.
- **Риски для схватки:** Нулевые.

---

## 3. Сводная таблица архитектурной готовности

| Механика сюжета | Готовность в ядре | Необходимые доработки | Затронутые модули |
|---|---|---|---|
| 1. Сбор ресурсов и база (H1, N1, N2) | **100% (Готово)** | Нет | `world.js`, `data.js` |
| 2. Линейные боевые столкновения | **100% (Готово)** | Нет | `units.js`, `path.js` |
| 3. Спасение спящих отрядов (H3, N3) | **85% (База есть)** | Спецификатор `isDormant`, триггер сближения | `missions/index.js`, `units.js` |
| 4. Ограничение найма (H3, N3) | **90% (База есть)** | Скрытие панели постройки в HUD | `hud.js`, `mission-hud.js` |
| 5. Эскорт обозов и саней (H4, N4) | **75% (База есть)** | Декларация `cart_wagon`, чекпоинты пути | `data.js`, `missions/index.js` |
| 6. Эвакуационные зоны (H4, N4) | **85% (База есть)** | Метод `w.remove(u)` по входу в зону | `missions/index.js` |
| 7. Динамические завалы и мосты | **90% (База есть)** | Добавление `w.setAreaBlocked()` | `world.js` |
| 8. Межмиссионные сохранения | **40% (Проектируется)**| Сохранение в `localStorage` | `game.js`, `missions/index.js` |

---

## 4. Задачи для передачи ведущему программисту (Sharrowkin)

1. [ ] **`src/world.js`:** Добавить методы `setTileBlocked(tx, ty, on)` и `setAreaBlocked(x0, y0, x1, y1, on)` для скриптовых динамических препятствий.
2. [ ] **`src/data.js`:** Внести запись `cart_wagon` для эскортируемых саней Карлиса и повозки архива (HP 800, броня 2, скорость 55, нет атаки).
3. [ ] **`src/missions/index.js`:** Расширить метод `MissionScenario.prototype.update` поддержкой условий `rescue`, `escort` и `evacuate`.
4. [ ] **`src/game.js`:** Реализовать простое чтение и запись `CampaignState` в `localStorage` для перехода между миссиями.
5. [ ] **`src/mission-hud.js`:** Добавить отображение прогресса для задач эскорта (`Обозы: 2/3 спасены`).
